from sqlalchemy import Column, Integer, String, Boolean, DateTime, ForeignKey, Text from sqlalchemy.orm import relationship, declarative_base from datetime import datetime

Base = declarative_base()

class User(Base): tablename = 'users'

id = Column(Integer, primary_key=True, index=True)
username = Column(String(50), unique=True, nullable=False)
password_hash = Column(String(128), nullable=False)
is_admin = Column(Boolean, default=False)
created_at = Column(DateTime, default=datetime.utcnow)

logs = relationship("EventLog", back_populates="user")

class Camera(Base): tablename = 'cameras'

id = Column(Integer, primary_key=True, index=True)
name = Column(String(100), nullable=False)
location = Column(String(100), nullable=True)
rtsp_url = Column(String(255), nullable=False)
is_active = Column(Boolean, default=True)
night_vision_enabled = Column(Boolean, default=False)
autofocus_enabled = Column(Boolean, default=True)
created_at = Column(DateTime, default=datetime.utcnow)

logs = relationship("EventLog", back_populates="camera")

class EventLog(Base): tablename = 'event_logs'

id = Column(Integer, primary_key=True, index=True)
user_id = Column(Integer, ForeignKey("users.id"))
camera_id = Column(Integer, ForeignKey("cameras.id"))
event_type = Column(String(50), nullable=False)
event_description = Column(Text, nullable=True)
timestamp = Column(DateTime, default=datetime.utcnow)

user = relationship("User", back_populates="logs")
camera = relationship("Camera", back_populates="logs")

