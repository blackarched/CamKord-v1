from pydantic import BaseModel, EmailStr, Field, conint
from typing import Optional, List
from datetime import datetime


# ========== AUTHENTICATION SCHEMAS ==========

class Token(BaseModel):
    access_token: str
    token_type: str = "bearer"

class TokenData(BaseModel):
    user_id: Optional[int] = None

class UserLogin(BaseModel):
    email: EmailStr
    password: str


# ========== USER SCHEMAS ==========

class UserBase(BaseModel):
    email: EmailStr

class UserCreate(UserBase):
    password: str

class UserResponse(UserBase):
    id: int
    created_at: datetime

    class Config:
        orm_mode = True


# ========== CAMERA SCHEMAS ==========

class CameraBase(BaseModel):
    name: str = Field(..., max_length=100)
    ip_address: str
    port: int = Field(..., gt=0, lt=65536)
    username: Optional[str]
    password: Optional[str]

class CameraCreate(CameraBase):
    pass

class CameraUpdate(BaseModel):
    name: Optional[str]
    ip_address: Optional[str]
    port: Optional[int]
    username: Optional[str]
    password: Optional[str]

class CameraResponse(CameraBase):
    id: int
    status: str
    last_checked: Optional[datetime]

    class Config:
        orm_mode = True


# ========== CAMERA SETTINGS ==========

class CameraSettings(BaseModel):
    camera_id: int
    night_vision: Optional[bool] = False
    auto_focus: Optional[bool] = True
    resolution: Optional[str] = "1080p"
    frame_rate: Optional[conint(gt=0, le=120)] = 30


# ========== STREAM CONTROL ==========

class StreamControl(BaseModel):
    camera_id: int
    action: str  # "start", "stop", "snapshot", etc.


# ========== LOGS & ACTIVITY ==========

class EventLog(BaseModel):
    id: int
    timestamp: datetime
    event_type: str
    camera_id: Optional[int]
    message: str

    class Config:
        orm_mode = True


# ========== DASHBOARD SUMMARY ==========

class DashboardStatus(BaseModel):
    total_cameras: int
    active_streams: int
    errors_today: int
    last_event: Optional[str]