from fastapi import FastAPI, WebSocket, Depends
from fastapi.middleware.cors import CORSMiddleware
from .auth import get_current_user

app = FastAPI(title="SecurityCam Suite API")

# CORS for frontend
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/health")
async def health_check():
    return {"status": "ok"}

# TODO: register routers for cameras, recordings, users, settings

@app.websocket("/ws/stream/{camera_id}")
async def stream_endpoint(websocket: WebSocket, camera_id: str, user=Depends(get_current_user)):
    await websocket.accept()
    # TODO: forward camera frames via WebSocket
    await websocket.close()