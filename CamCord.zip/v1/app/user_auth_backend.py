user_auth_backend.py

Production-ready user authentication backend using FastAPI with JWT

from fastapi import APIRouter, HTTPException, Depends, status from fastapi.security import OAuth2PasswordBearer, OAuth2PasswordRequestForm from passlib.context import CryptContext from jose import JWTError, jwt from datetime import datetime, timedelta from pydantic import BaseModel import sqlite3

SECRET_KEY = "a_very_secret_key_please_change" ALGORITHM = "HS256" ACCESS_TOKEN_EXPIRE_MINUTES = 60

auth_router = APIRouter()

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto") oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/auth/token")

class Token(BaseModel): access_token: str token_type: str

class TokenData(BaseModel): username: str | None = None

class User(BaseModel): username: str disabled: bool = False

class UserInDB(User): hashed_password: str

def get_db_user(username: str): conn = sqlite3.connect("camera_tool.db") cursor = conn.cursor() cursor.execute("SELECT username, password FROM users WHERE username = ?", (username,)) row = cursor.fetchone() conn.close() if row: return UserInDB(username=row[0], hashed_password=row[1]) return None

def verify_password(plain_password, hashed_password): return pwd_context.verify(plain_password, hashed_password)

def authenticate_user(username: str, password: str): user = get_db_user(username) if not user or not verify_password(password, user.hashed_password): return False return user

def create_access_token(data: dict, expires_delta: timedelta | None = None): to_encode = data.copy() expire = datetime.utcnow() + (expires_delta or timedelta(minutes=15)) to_encode.update({"exp": expire}) return jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)

async def get_current_user(token: str = Depends(oauth2_scheme)): credentials_exception = HTTPException( status_code=status.HTTP_401_UNAUTHORIZED, detail="Could not validate credentials", headers={"WWW-Authenticate": "Bearer"}, ) try: payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM]) username: str = payload.get("sub") if username is None: raise credentials_exception token_data = TokenData(username=username) except JWTError: raise credentials_exception user = get_db_user(username=token_data.username) if user is None: raise credentials_exception return user

@auth_router.post("/auth/token", response_model=Token) async def login_for_access_token(form_data: OAuth2PasswordRequestForm = Depends()): user = authenticate_user(form_data.username, form_data.password) if not user: raise HTTPException( status_code=status.HTTP_401_UNAUTHORIZED, detail="Incorrect username or password", headers={"WWW-Authenticate": "Bearer"}, ) access_token = create_access_token(data={"sub": user.username}) return {"access_token": access_token, "token_type": "bearer"}

@auth_router.get("/auth/me", response_model=User) async def read_users_me(current_user: User = Depends(get_current_user)): return current_user

