dashboard_backend.py

import os import cv2 import threading import time from typing import List, Optional, Generator from fastapi import APIRouter, FastAPI, Depends, HTTPException from fastapi.responses import StreamingResponse, JSONResponse from sqlalchemy.orm import Session

from database import SessionLocal, init_db from database import User, EventLog, CameraSettings from security_utils import get_current_user from camera_module import CameraManager from camera_controls import apply_image_adjustments, apply_night_vision_filter

--- Initialize database ---

init_db()

--- Global Camera Manager ---

camera_manager = CameraManager()

--- Router Setup ---

router = APIRouter(prefix="/api")

--- Dependency ---

def get_db() -> Session: db = SessionLocal() try: yield db finally: db.close()

--- World-Class Feature: Real-Time Object Detection Overlay ---

Uses OpenCV DNN with YOLOv4-Tiny for lightweight, production-grade inference.

class ObjectDetector: def init(self, cfg_path: str, weights_path: str, classes_path: str, confidence_threshold=0.5, nms_threshold=0.4): self.net = cv2.dnn.readNetFromDarknet(cfg_path, weights_path) self.net.setPreferableBackend(cv2.dnn.DNN_BACKEND_OPENCV) self.net.setPreferableTarget(cv2.dnn.DNN_TARGET_CPU) self.layer_names = self.net.getLayerNames() self.output_layers = [self.layer_names[i[0] - 1] for i in self.net.getUnconnectedOutLayers()] with open(classes_path, 'r') as f: self.classes = [line.strip() for line in f] self.conf_threshold = confidence_threshold self.nms_threshold = nms_threshold

def detect(self, frame):
    h, w = frame.shape[:2]
    blob = cv2.dnn.blobFromImage(frame, 1/255.0, (416, 416), swapRB=True, crop=False)
    self.net.setInput(blob)
    outs = self.net.forward(self.output_layers)
    boxes, confidences, class_ids = [], [], []
    for out in outs:
        for detection in out:
            scores = detection[5:]
            class_id = int(scores.argmax())
            confidence = float(scores[class_id])
            if confidence > self.conf_threshold:
                box = detection[0:4] * [w, h, w, h]
                center_x, center_y, bw, bh = box.astype('int')
                x = int(center_x - bw / 2)
                y = int(center_y - bh / 2)
                boxes.append([x, y, int(bw), int(bh)])
                confidences.append(confidence)
                class_ids.append(class_id)
    idxs = cv2.dnn.NMSBoxes(boxes, confidences, self.conf_threshold, self.nms_threshold)
    results = []
    if len(idxs) > 0:
        for i in idxs.flatten():
            x, y, bw, bh = boxes[i]
            label = self.classes[class_ids[i]]
            conf = confidences[i]
            results.append((x, y, bw, bh, label, conf))
    return results

Instantiate detector (paths should be configured)

DETECTOR = ObjectDetector( cfg_path='models/yolov4-tiny.cfg', weights_path='models/yolov4-tiny.weights', classes_path='models/coco.names' )

--- Streaming with Object Detection ---

def object_detection_stream(camera_id: int) -> Generator[bytes, None, None]: cap = camera_manager.open_camera(camera_id) while True: ret, frame = cap.read() if not ret: break

# Apply user-defined settings
    settings = camera_manager.get_settings(camera_id)
    if settings.night_vision:
        frame = apply_night_vision_filter(frame)
    frame = apply_image_adjustments(frame, settings)

    # Perform object detection
    detections = DETECTOR.detect(frame)
    for (x, y, bw, bh, label, conf) in detections:
        color = (0, 255, 0)
        cv2.rectangle(frame, (x, y), (x + bw, y + bh), color, 2)
        cv2.putText(frame, f"{label}:{conf:.2f}", (x, y - 5), cv2.FONT_HERSHEY_SIMPLEX, 0.5, color, 1)

    ret, jpeg = cv2.imencode('.jpg', frame)
    if not ret:
        continue
    yield (b'--frame\r\n'
           b'Content-Type: image/jpeg\r\n\r\n' + jpeg.tobytes() + b'\r\n')
cap.release()

--- API Endpoints ---

@router.get('/cameras', tags=['Cameras']) def list_cameras(user=Depends(get_current_user)): cams = camera_manager.list_cameras() return cams

@router.get('/cameras/{camera_id}/feed', tags=['Cameras']) def camera_feed(camera_id: int, user=Depends(get_current_user)): return StreamingResponse(object_detection_stream(camera_id), media_type='multipart/x-mixed-replace; boundary=frame')

@router.get('/events', tags=['Logs']) def get_events(limit: int = 100, db: Session = Depends(get_db), user=Depends(get_current_user)): events = db.query(EventLog).order_by(EventLog.timestamp.desc()).limit(limit).all() return [{'timestamp': e.timestamp, 'camera_id': e.camera_id, 'type': e.event_type, 'message': e.message} for e in events]

@router.get('/settings/{camera_id}', tags=['Settings']) def get_camera_settings(camera_id: str, db: Session = Depends(get_db), user=Depends(get_current_user)): settings = db.query(CameraSettings).filter_by(camera_id=str(camera_id)).first() if not settings: raise HTTPException(status_code=404, detail='Settings not found') return settings.dict

@router.post('/settings/{camera_id}', tags=['Settings']) def update_camera_settings(camera_id: str, settings: CameraSettings, db: Session = Depends(get_db), user=Depends(get_current_user)): record = db.query(CameraSettings).filter_by(camera_id=str(camera_id)).first() if not record: record = CameraSettings(camera_id=str(camera_id)) db.add(record) for field in ['name', 'resolution', 'night_vision', 'autofocus', 'brightness', 'contrast', 'saturation', 'sharpness', 'microphone_enabled']: setattr(record, field, getattr(settings, field)) db.commit() return {'message': 'Settings updated'}

--- Application Mounting ---

app = FastAPI(title='SecurityCam Dashboard API') app.include_router(router)

Health check

@app.get('/health') def health(): return {'status': 'ok'}

if name == 'main': # Launch with: uvicorn dashboard_backend:app --host 0.0.0.0 --port 8001 uvicorn.run('dashboard_backend:app', host='0.0.0.0', port=8001, reload=False)

